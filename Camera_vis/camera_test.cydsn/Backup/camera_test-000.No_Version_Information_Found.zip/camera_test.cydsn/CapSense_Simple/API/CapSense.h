#ifndef `$INSTANCE_NAME`_H
#define `$INSTANCE_NAME`_H
#include "`$INSTANCE_NAME`_PWM.h"
#define `$INSTANCE_NAME`_Start() `$INSTANCE_NAME`_PWM_Start()
#endif
