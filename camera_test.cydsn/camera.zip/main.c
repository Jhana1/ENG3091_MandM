#include <project.h>
#include <stdio.h>
#include <stdlib.h>
#include <my_camera_functions.h>
#include <blob_stats.h>

char display[2][20];
char RGB[] = "KRGB";
int16 disp = 0, m = 0, c = 0;
extern blob blobs[255];
extern uint8 RED_U; //116;
extern uint8 RED_V;//140;//162;
extern uint8 GREEN_U;//128;
extern uint8 GREEN_V;//102;
extern uint8 BLUE_U;//115 //138;//162;
extern uint8 BLUE_V;//124;//116;
void button_handle();

void image_stuff();
void image_stuff2();
void image_stuff3();

uint8 exposure, gain, bgain;
uint16 blobn;
int dis[3], stack[3];

int PWM_Val = 24;
// Exposure, White Balance, Gain, Gamma
CY_ISR(menu)
{
    //button_handle();
    switch(disp)
    {
        case 0:
            bgain = Camera_ReadReg(0x01);
            bgain += 5;
            Camera_WriteReg(0x01,bgain);
            sprintf(display[0],"Bgain:%u   ",bgain);
            LCD_PosPrintString(0,0,display[0]);
            break;
        case 1:
            bgain = Camera_ReadReg(0x01);
            bgain--;
            Camera_WriteReg(0x01,bgain);
            sprintf(display[0],"Bgain:%u   ",bgain);
            LCD_PosPrintString(0,0,display[0]);
            break;
        case 2:
            break;
        case 3:
            BLUE_V = BLUE_V - 1;
            break;
        default:
            break;
    }
    but0_ClearPending();
}
CY_ISR(change)
{
    disp = (disp + 1) % 6;
    if(disp == 2)
    {
        LCD_PosPrintString(1,0,"Capture Image?  ");
    }
    but1_ClearPending();
}

int main()
{
    CyDelay(3000);
    m = 1;
    int i = 0;
    LCD_Start();
    Arm_Start();
    CyGlobalIntEnable;
    CS_Buttons_Start();
    but0_StartEx(menu);
    but1_StartEx(change);
    USB_Start(0,USB_DWR_VDDD_OPERATION);
    while(!USB_GetConfiguration());
    
    Arm_WriteCompare(50);
    CyDelay(5000);
    Arm_WriteCompare(PWM_Val);
    
    
    init_camera();
    set_gain_exposure(1);
    
    USB_CDC_Init(); //enable receiving data from USB host
    while(!USB_DataIsReady()); //wait until data is received on USB for synchronisation
    
    for(;;)
    {
        //image_stuff();
        image_stuff();
        if(disp == 4)
        {
            char l[] = {'N','C','L','R'};
            LCD_ClearDisplay();
            sprintf(display[0],"#:%d R:%c G:%c B:%c",blobn,l[dis[0]+1],l[dis[1]+1],l[dis[2]+1]);
            LCD_PosPrintString(0,0,display[0]);
            for(i = 0; i < 16; i++)
            {
                if(blobs[i].size >= 50);
                    LCD_PosPutChar(1,i,RGB[blobs[i].colour]);
            }
        }
        if(disp == 5)
        {
            LCD_ClearDisplay();
            sprintf(display[0],"x:%u xc:%lu",blobs[0].x_sum,blobs[0].x_sum/blobs[0].size);
            sprintf(display[1],"y:%u yc:%lu",blobs[0].y_sum,blobs[0].y_sum/blobs[0].size);
            LCD_PosPrintString(0,0,display[0]);
            LCD_PosPrintString(1,0,display[1]);
        }
    }
}

void button_handle()
{
    // Display Major Values, Resets Auto...
    //Camera_WriteReg(0x13,0b11100000); // Enable Auto Gain etc...
    switch(disp)
    {
        case(0) :
        //Exposure Increment
            exposure = Camera_ReadReg(0x10);
            Camera_WriteReg(0x10,exposure+5); 
            sprintf(display[0],"Exposure: %d",exposure + 5);
        break;
        case(1) :
        //Gain
        //Gain
            gain = Camera_ReadReg(0x00);
            Camera_WriteReg(0x00,gain+5);
            bgain = Camera_ReadReg(0x01);
            //Camera_WriteReg(0x01,bgain+5);
            sprintf(display[1],"Gain+B: %d",gain+5);
        break;
        case(2) :
        // Exposure Decrement
            exposure = Camera_ReadReg(0x10);
            Camera_WriteReg(0x10,exposure-1); 
            sprintf(display[0],"Exposure: %d",exposure - 1);
        break;
        case(3) :
        //Gain Decrement
            gain = Camera_ReadReg(0x00);
            Camera_WriteReg(0x00,gain-1);
            bgain = Camera_ReadReg(0x01);
            //Camera_WriteReg(0x01,bgain+5);
            sprintf(display[1],"Gain+B: %d",gain-1);
        break;
    } 
    LCD_ClearDisplay();
    LCD_PosPrintString(0,0,display[0]);
    LCD_PosPrintString(1,0,display[1]);
}

void image_stuff()
{
    int i;
    capture_image();
    //LCD_ClearDisplay();
    //LCD_PosPrintString(0,0,"Sending......");
    for(i=0;i<sizeof Camera_framebuffer;i+=64)
    {
        while(!USB_CDCIsReady()); //wait until USB is ready
        USB_PutData((uint8*)Camera_framebuffer+i,64); //send next 64 byte packet (maximum size)
    }
    //LCD_PosPrintString(0,0,"Sent....");
        threshold_image();
        clean_frame(RED,0.3,144/3);
        blob_detect();
        dis[0] = to_nearest_blob(RED,50);
        dis[1] = to_nearest_blob(GREEN,50);
        dis[2] = to_nearest_blob(BLUE,50);
        blobn = blob_count(50);
        for(i=0;i<sizeof Camera_framebuffer;i+=64)
        {
            while(!USB_CDCIsReady()); //wait until USB is ready
            USB_PutData((uint8*)Camera_framebuffer+i,64); //send next 64 byte packet (maximum size)
        }
        //LCD_PosPutChar(1,15,RGB[identify_colour_instructions()]);
}

void image_stuff2()
{
    LCD_PosPrintString(0,0,"                ");
    LCD_PosPrintString(0,0,"Getting Image");
    capture_thresh_image();   
    LCD_PosPrintString(0,0,"Success!!!      ");
    char RGB[] = {'K', 'R', 'G', 'B'};
    int x = identify_colour_instructions(50);
    sprintf(display[1],"Colour: %d",x);
    LCD_PosPrintString(1,0,display[1]);
}
void image_stuff3()
{
    capture_thresh_image();
    while(identify_colour_instructions(100) == 0)
    {
        Arm_WriteCompare(++PWM_Val);
        CyDelay(1000);
        if(PWM_Val >= 50)
        {
            return;
        }
        sprintf(display[0],"Arm:%d, C:%d",PWM_Val,identify_colour_instructions(100));
        LCD_ClearDisplay();
        LCD_PosPrintString(0,0,display[0]);
        capture_thresh_image();
    }
    stack[0] = identify_colour_instructions(100);
    PWM_Val += 5;
    Arm_WriteCompare(PWM_Val);
    CyDelay(5000);
    capture_thresh_image();
    stack[1] = identify_colour_instructions(100);
    PWM_Val += 5;
    Arm_WriteCompare(PWM_Val);
    CyDelay(5000);
    capture_thresh_image();
    stack[2] = identify_colour_instructions(100);
    sprintf(display[0],"1:%c 2:%c 3:%c",RGB[stack[0]],RGB[stack[1]],RGB[stack[2]]);
    LCD_ClearDisplay();
    LCD_PosPrintString(1,0,display[0]);
    //LCD_PosPrintString(1,0,"Done... Really.");
}