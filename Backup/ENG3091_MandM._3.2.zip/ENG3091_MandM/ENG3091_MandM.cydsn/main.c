/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#include <stdio.h>
#include <stdarg.h>
#include <math.h>

#include <mice.h>
#include <mouse_a.h>
#include <mouse_b.h>
#include <motor.h>
#include <navigation.h>
#include <buttons.h>
#include <compass.h>
#include <ultrasonic.h>

//this is in navigation.c
extern struct Position location;
//these are in button.c
extern volatile uint8 but0_b;
extern volatile uint8 but1_b;
//These are in compass.c
extern int16 compass_x;
extern int16 compass_y;
extern int16 compass_z;
extern int16 compass_heading;
extern volatile uint8 compass_ready;
//This is in ultrasonic.c
extern volatile uint16 ultra_distance;

// print() function, works like snprintf(). See: http://www.cplusplus.com/reference/cstdio/snprintf/

void print(const char *fmt, ...)
{
   if(!USB_GetConfiguration()) return;  // Do nothing if the USB cable is not connected.
   char buffer[64];
   va_list args;
   va_start(args, fmt);
   vsnprintf(buffer, sizeof(buffer), fmt, args);
   va_end(args);
   while(!USB_CDCIsReady());
   USB_PutString(buffer);
}

void rotate_left(int speed){
    setForward(MRIGHT);
    setReverse(MLEFT);
    setSpeed(MBOTH, speed);
}

void rotate_right(int speed){
    setForward(MLEFT);
    setReverse(MRIGHT);
    setSpeed(MBOTH, speed);
}

int main()
{
    /* ** INITIALIZE COMPONENTS ** */
    LCD_Start();
    Timer_Start();
    //USB_Start(0, USB_DWR_VDDD_OPERATION);
    //CyDelay(1000); give camera time to boot up
    
    //start_mice();
    //start_navigation();
    start_motors();
    start_buttons();
    start_compass();
    //start_ultrasonic();
    
    /* ** DECLARE VARIABLES ** */
    char outString[16];  // String to hold the ascii result
    uint32 time;
    extern volatile int32 loc_y_a;
    extern volatile int32 loc_y_b;
    
    CyGlobalIntEnable;
    /* INFINITE LOOP */
    
    int state = 0;
    int distance = 4000;
    int desired_heading = 0;
    for(;;)
    {   
        time = Timer_ReadCounter();
        
        switch (state){
            case 0:
            desired_heading = 0;
            break;
            case 1:
            desired_heading = 90;
            break;
        }
        
        int heading_error = desired_heading - compass_heading;
        if (abs(heading_error) > 5){
            if (heading_error < 0){ //actual heading is greater than the heading
                rotate_right(abs(heading_error)*10);
            } else {
                rotate_left(abs(heading_error)*10);
            }
        }
        
        //Read the compass when it is ready for reading
        if (compass_ready){
            compass_ready = 0;
            compass_read();
            //print("%d %d %d\n", compass_x, compass_y, compass_z);
        }
        
        //Handle buttons
        if (but1_b){
            but1_b = 0;
            state = 0;
        } else if (but0_b){
            but0_b = 0;
            state = 1;
        }
        
        //Print some info to the screen
        if ((time % 1000) == 0){
            sprintf(outString, "h%d dh:%d e:%d", compass_heading, desired_heading, heading_error);
            LCD_ClearDisplay();
            LCD_PosPrintString(0,0,outString);
            sprintf(outString, "yl%ld yr%ld", loc_y_a, loc_y_b);
            LCD_PosPrintString(1,0,outString);
        }
        

    }
}